// ===== Налаштування за замовчуванням (змінюються в грі через ⚙) =====
const DEF = {edge:95, max:90, min:0.5, bonus:10, secs:60, sound:true, fast:false};
const START_BALANCE = 100;
const SKIN_TARGET = 3000;   // скільки скінів у каталозі (унікальні скіни × стани зносу + StatTrak)
const CASE_LIMIT = 150;     // скільки кейсів

// ===== Переклади =====
const I18N = {
  uk:{
    sim:"симулятор", navU:"Апгрейд", navC:"Кейси", navA:"Календар",
    balance:"Баланс:", coins:"монет", timer:"+{n} монет через {s} с",
    inventory:"Ваш інвентар", sellSel:"Продати вибрані",
    pickStake:"Оберіть скіни для ставки", pickMany:"Можна обрати кілька скінів",
    pickTarget:"Оберіть скін для апгрейду", pickSub:"Чим дорожча ціль, тим менший шанс",
    sel:"Обрано", balStake:"Сума балансу:", max:"макс.",
    chLow:"низький шанс", chMid:"середній шанс", chHigh:"високий шанс", chanceLbl:"Шанс:",
    upgrade:"Покращити", skip:"Пропустити", mult:"Множник", target:"Ціль", stake:"Ставка",
    note:"Це навчальний симулятор: усі монети й скіни віртуальні, реальних грошей тут немає. Ціни приблизні. Не пов'язано з Valve.",
    search:"Пошук скіна…",
    tAll:"Усі категорії", tRifle:"Гвинтівки", tSniper:"Снайперські", tPistol:"Пістолети", tSmg:"Пістолети-кулемети",
    tShotgun:"Дробовики", tMg:"Кулемети", tKnife:"Ножі", tGloves:"Рукавички",
    rAll:"Усі ціни", rCheap:"Дешеві (до 10)", rMid:"Середні (10–99)", rHigh:"Дорогі (100–999)", rTop:"Дуже дорогі (1000–9999)", rUltra:"Преміум (10 000–99 999)", rMega:"Легендарні (100 000+)",
    sAsc:"Спочатку дешеві", sDesc:"Спочатку дорогі", sAz:"За назвою", sell:"Продати", buy:"Купити за",
    emptyInv:"Інвентар порожній. Купіть скін, відкрийте кейс або заберіть подарунок.", nothing:"Нічого не знайдено",
    win:"Перемога! Отримано: ", lose:"Не пощастило. Ставку втрачено.", dropped:"Випало:",
    e_money:"Недостатньо монет", e_pick:"Спершу виберіть скіни або суму балансу для ставки",
    upgrades:"Апгрейдів", wins:"Успішних", casesN:"Кейсів", feed:"Стрічка подій", feedEmpty:"Подій ще немає",
    open:"Відкрити", cSearch:"Пошук кейса…", cCount:"кейсів", cAsc:"Спочатку дешеві", cDesc:"Спочатку дорогі", cAz:"За назвою",
    advToday:"Подарунок дня", advGot:"Забрано", streak:"Серія", advNext:"Наступний через", claim:"Забрати",
    f_case:"Кейс «{c}» → {i}", f_win:"Апгрейд вдалий ({ch}%): {s} → {i}",
    f_lose:"Апгрейд невдалий ({ch}%): втрачено {s} (ціль: {i})", f_adv:"Подарунок дня {d}: {r}",
    setTitle:"Налаштування", setEdge:"Коефіцієнт шансу, % (100 = чесно, менше = складніше)",
    setMax:"Максимальний шанс, %", setMin:"Мінімальний шанс, %", setBonus:"Бонус, монет",
    setSecs:"Бонус кожні, секунд", close:"Закрити",
    infoTitle:"Як це працює",
    info1:"Ви ставите скіни та/або монети з балансу й обираєте скін, який хочете отримати.",
    info2:"Шанс = вартість ставки ÷ вартість цілі × коефіцієнт. Чим дорожча ціль, тим менший шанс.",
    info3:"Зелена зона на колесі — це ваш шанс. Якщо стрілка зупиниться в зеленій зоні, ви отримаєте ціль, інакше ставка згорає.",
    info4:"Кнопки x2, x4… та відсотки підбирають ціль самі. Усі монети й скіни віртуальні."
  },
  en:{
    sim:"simulator", navU:"Upgrade", navC:"Cases", navA:"Calendar",
    balance:"Balance:", coins:"coins", timer:"+{n} coins in {s}s",
    inventory:"Your inventory", sellSel:"Sell selected",
    pickStake:"Pick skins to stake", pickMany:"You can pick several skins",
    pickTarget:"Pick a skin to upgrade to", pickSub:"The pricier the target, the lower the chance",
    sel:"Selected", balStake:"Balance amount:", max:"max",
    chLow:"low chance", chMid:"medium chance", chHigh:"high chance", chanceLbl:"Chance:",
    upgrade:"Upgrade", skip:"Skip", mult:"Multiplier", target:"Target", stake:"Stake",
    note:"This is an educational simulator: all coins and skins are virtual, no real money involved. Prices are approximate. Not affiliated with Valve.",
    search:"Search skin…",
    tAll:"All categories", tRifle:"Rifles", tSniper:"Snipers", tPistol:"Pistols", tSmg:"SMGs",
    tShotgun:"Shotguns", tMg:"Machine guns", tKnife:"Knives", tGloves:"Gloves",
    rAll:"All prices", rCheap:"Cheap (under 10)", rMid:"Medium (10–99)", rHigh:"Expensive (100–999)", rTop:"Very expensive (1000–9999)", rUltra:"Premium (10,000–99,999)", rMega:"Legendary (100,000+)",
    sAsc:"Cheapest first", sDesc:"Most expensive first", sAz:"By name", sell:"Sell", buy:"Buy for",
    emptyInv:"Inventory is empty. Buy a skin, open a case or claim a gift.", nothing:"Nothing found",
    win:"You won: ", lose:"Unlucky. Your stake is lost.", dropped:"You got:",
    e_money:"Not enough coins", e_pick:"Pick skins or a balance amount to stake first",
    upgrades:"Upgrades", wins:"Won", casesN:"Cases", feed:"Live feed", feedEmpty:"No events yet",
    open:"Open", cSearch:"Search case…", cCount:"cases", cAsc:"Cheapest first", cDesc:"Most expensive first", cAz:"By name",
    advToday:"Gift of the day", advGot:"Claimed", streak:"Streak", advNext:"Next gift in", claim:"Claim",
    f_case:"Case “{c}” → {i}", f_win:"Upgrade success ({ch}%): {s} → {i}",
    f_lose:"Upgrade failed ({ch}%): lost {s} (target: {i})", f_adv:"Day {d} gift: {r}",
    setTitle:"Settings", setEdge:"Chance multiplier, % (100 = fair, lower = harder)",
    setMax:"Max chance, %", setMin:"Min chance, %", setBonus:"Bonus coins",
    setSecs:"Bonus every, seconds", close:"Close",
    infoTitle:"How it works",
    info1:"You stake skins and/or balance coins and pick the skin you want to get.",
    info2:"Chance = stake value ÷ target value × multiplier. The pricier the target, the lower the chance.",
    info3:"The green zone on the wheel is your chance. If the pointer stops inside it you win the target, otherwise the stake is lost.",
    info4:"The x2, x4… and percent buttons pick a target for you. All coins and skins are virtual."
  }
};
let lang = (()=>{ try{ const l = localStorage.getItem("upg_lang"); return I18N[l] ? l : "uk"; }catch(e){ return "uk"; } })();
const t = k => I18N[lang][k] || k;
const f = (k, o) => t(k).replace(/\{(\w+)\}/g, (_, x) => o[x]);

// ===== Малюнки-запасні (SVG) =====
const SHAPES = {
  rifle:'<path d="M3 17l19-2v15L8 33z"/><rect x="22" y="14" width="46" height="14" rx="2"/><path d="M38 28h9l-3 15h-9z"/><path d="M26 28h7l-2 11h-6z"/><rect x="68" y="18" width="48" height="5" rx="1"/>',
  sniper:'<path d="M3 17l19-2v15L8 33z"/><rect x="22" y="14" width="44" height="13" rx="2"/><path d="M30 27h7l-2 12h-6z"/><rect x="66" y="18" width="52" height="4" rx="1"/><rect x="36" y="6" width="30" height="7" rx="3"/><rect x="48" y="12" width="5" height="3"/>',
  pistol:'<rect x="28" y="14" width="60" height="12" rx="2"/><path d="M34 26h18l-5 20H32z"/><rect x="88" y="17" width="10" height="5"/>',
  smg:'<rect x="8" y="19" width="18" height="4" rx="1"/><rect x="26" y="15" width="52" height="13" rx="2"/><rect x="78" y="19" width="26" height="5" rx="1"/><rect x="44" y="28" width="8" height="18" rx="1"/><path d="M30 28h7l-2 11h-6z"/>',
  shotgun:'<path d="M3 17l19-2v15L8 33z"/><rect x="22" y="15" width="40" height="11" rx="2"/><rect x="40" y="26" width="26" height="6" rx="1"/><rect x="62" y="18" width="54" height="5" rx="1"/>',
  mg:'<path d="M3 17l19-2v15L8 33z"/><rect x="22" y="14" width="50" height="14" rx="2"/><rect x="40" y="28" width="22" height="14" rx="2"/><rect x="72" y="18" width="42" height="5" rx="1"/>',
  knife:'<path d="M12 38C34 8 82 4 112 20 84 22 52 30 12 38z"/><path d="M4 40l12-6 4 7-12 5z"/>',
  gloves:'<path d="M32 44V27l-8-10 4-3 8 9V9h5v15h3V6h5v18h3V9h5v17h3V16h5v22c0 6-6 8-12 8H40c-5 0-8-2-8-2z"/>'
};
let gid = 0;
function svgIcon(c){
  const id = "g" + (++gid);
  return `<svg viewBox="0 0 120 50"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="${c[4]}"/><stop offset=".55" stop-color="${c[5]}"/><stop offset="1" stop-color="${c[4]}"/>
    </linearGradient></defs><g fill="url(#${id})" stroke="rgba(255,255,255,.35)" stroke-width="1">${SHAPES[c[3]]}</g></svg>`;
}
// ===== Каталог: 300 скінів. Формат рядка: Зброя:Скін,ціна,рідкість;Скін,ціна,рідкість =====
// Рідкість: ww, ind, mil, res, cls, cov, gold. Ціни приблизні (ринок Steam, $), їх можна змінювати.
const RAW = `
AK-47:Safari Mesh,0.3,ww;Elite Build,2,mil;Uncharted,1.4,ind;Slate,3,mil;Point Disarray,8,mil;Blue Laminate,9,mil;Frontside Misty,7,res;Phantom Disruptor,12,res;Jaguar,14,res;Redline,26,res;Bloodsport,45,cls;Neon Rider,55,cls;Asiimov,70,cls;Vulcan,160,cls;Hydroponic,200,cov;Fire Serpent,900,cov
M4A4:Urban DDPAT,0.4,ww;Faded Zebra,2,ind;Evil Daimyo,3,mil;Radiation Hazard,6,mil;Griffin,8,res;Desert-Strike,12,res;Desolate Space,16,cls;Neo-Noir,22,cls;Buzz Kill,24,cls;The Emperor,38,cov;Asiimov,55,cov;Howl,3200,cov
M4A1-S:Boreal Forest,0.5,ww;Nitro,2,ind;Blood Tiger,5,mil;Guardian,10,res;Cyrex,12,cls;Atomic Alloy,16,res;Chantico's Fire,18,cls;Decimator,28,cls;Golden Coil,40,cls;Hyper Beast,45,cov;Printstream,75,cov;Knight,330,cov
Galil AR:Sandstorm,0.5,ww;Stone Cold,2,ind;Sugar Rush,4,mil;Eco,6,mil;Cerberus,7,res;Chatterbox,18,cov
FAMAS:Colony,0.3,ww;Djinn,3,mil;Pulse,4,mil;Mecha Industries,7,res;Roll Cage,8,cls;Afterimage,16,cls
AUG:Torque,1,ind;Stymphalian,5,mil;Chameleon,6,mil;Bengal Tiger,14,res;Syd Mead,12,cls;Akihabara Accept,55,cov
SG 553:Army Sheen,0.3,ww;Pulse,3,mil;Cyrex,4,mil;Integrale,5,res;Tiger Moth,8,cls;Phantom,9,res
AWP:Safari Mesh,0.6,ww;Pit Viper,1.5,ind;Capillary,3,mil;Atheris,5,mil;Phobos,6,mil;Redline,14,res;Man-o'-war,20,res;Corticera,18,res;Electric Hive,40,res;Neo-Noir,25,cls;Hyper Beast,40,cls;Containment Breach,35,cov;Asiimov,65,cov;Lightning Strike,85,cov;Dragon Lore,2300,cov;Gungnir,8500,cov
SSG 08:Lichen Dashed,0.4,ww;Dark Water,1.5,ind;Abyss,3,mil;Death Strike,8,res;Big Iron,12,res;Ghost Crusader,10,res;Dragonfire,18,cls;Blood in the Water,22,cov
SCAR-20:Sand Mesh,0.2,ww;Contractor,0.5,ind;Cardiac,8,res;Cyrex,5,res;Emerald,6,res;Bloodsport,15,cls
G3SG1:Arctic Camo,0.2,ww;Murky,0.6,ind;Demeter,1,mil;Flux,2,mil;Stinger,4,res;Chronos,12,cov
Glock-18:Sand Dune,0.2,ww;Death Rattle,1.5,ind;Candy Apple,4,mil;Water Elemental,6,mil;Steel Disruption,8,res;Moonrise,5,res;Bunsen Burner,14,res;Twilight Galaxy,14,res;Wasteland Rebel,22,cls;Fade,580,cls
USP-S:Forest Leaves,0.4,ww;Para Green,1,ind;Guardian,7,res;Cortex,12,mil;Overgrowth,10,res;Caiman,14,res;Orion,12,res;Neo-Noir,18,cls;Printstream,55,cov;Kill Confirmed,85,cov
P2000:Granite Marbleized,0.2,ww;Scorpion,0.8,ind;Corticera,5,mil;Amber Fade,6,res;Fire Elemental,12,cls
P250:Sand Dune,0.1,ww;Whiteout,0.5,ind;Cartel,3,mil;Supernova,4,mil;Muertos,3,mil;Mehndi,2,mil;Asiimov,12,cls;Nuclear Threat,55,cls
Desert Eagle:Urban Rubble,0.3,ww;Oxide Blaze,4,mil;Hypnotic,8,mil;Conspiracy,4,res;Cobalt Disruption,18,res;Kumicho Dragon,14,cls;Printstream,55,cov;Blaze,330,cls
Five-SeveN:Forest Night,0.2,ww;Monkey Business,6,res;Copper Galaxy,6,res;Hyper Beast,12,cls;Angry Mob,14,cls
Tec-9:Sandstorm,0.2,ww;Isaac,5,mil;Fuel Injector,12,cls
CZ75-Auto:Green Plaid,0.2,ww;Tigris,3,res;Victoria,9,cls
R8 Revolver:Reboot,1,ind;Llama Cannon,3,res;Fade,25,cls
Dual Berettas:Briar,0.5,mil;Cobra Strike,10,cls
MP9:Sand Dashed,0.2,ww;Storm,0.5,ind;Bulldozer,6,res;Airlock,8,res;Hot Rod,40,cls
MAC-10:Palm,0.5,ww;Silver,0.3,ind;Heat,6,mil;Curse,3,mil;Stalker,12,res;Neon Rider,25,cls
MP7:Army Recon,0.2,ww;Skulls,1.2,ind;Cirrus,6,mil;Nemesis,4,res;Bloodsport,25,cls
MP5-SD:Gauss,0.5,mil;Phosphor,2,mil;Lab Rats,5,res
UMP-45:Mudder,0.2,ww;Carbon Fiber,0.3,ind;Scaffold,3,mil;Primal Saber,9,res;Momentum,15,cls;Arctic Wolf,9,cls
P90:Sand Spray,0.2,ww;Ash Wood,0.8,ind;Module,2,mil;Trigon,2,mil;Asiimov,14,cls;Emerald Dragon,40,cov;Death by Kitty,40,cov
PP-Bizon:Sand Dashed,0.2,ww;Water Sigil,1,mil;Fuel Rod,5,res;Judgement of Anubis,8,cls
Nova:Polar Mesh,0.3,ww;Bloomstick,12,res;Hyper Beast,10,cls;Antique,25,cls
XM1014:Blue Spruce,0.2,ww;Tranquility,2,mil;Incinegator,3,mil;Seasons,8,res
MAG-7:Sand Dune,0.2,ww;Bulldozer,0.5,ind;Heaven Guard,1,mil;Memento,6,res
Sawed-Off:Forest DDPAT,0.2,ww;Highwayman,2,mil;The Kraken,12,cls
M249:Jungle DDPAT,0.2,ww;Nebula Crusader,1,mil;Emerald Poison Dart,6,res
Negev:Army Sheen,0.2,ww;Power Loader,2,mil;Lionfish,8,res
Karambit:Safari Mesh,290,gold;Forest DDPAT,330,gold;Case Hardened,450,gold;Slaughter,520,gold;Doppler,560,gold;Tiger Tooth,640,gold;Marble Fade,1000,gold;Fade,1150,gold
M9 Bayonet:Safari Mesh,190,gold;Forest DDPAT,220,gold;Case Hardened,400,gold;Slaughter,480,gold;Doppler,520,gold;Marble Fade,950,gold;Fade,1000,gold
Bayonet:Safari Mesh,110,gold;Forest DDPAT,120,gold;Case Hardened,250,gold;Slaughter,300,gold;Doppler,340,gold;Marble Fade,520,gold
Butterfly Knife:Forest DDPAT,280,gold;Case Hardened,480,gold;Slaughter,620,gold;Tiger Tooth,800,gold;Doppler,850,gold;Marble Fade,1500,gold
Flip Knife:Safari Mesh,95,gold;Case Hardened,190,gold;Doppler,240,gold;Fade,560,gold
Gut Knife:Safari Mesh,45,gold;Case Hardened,95,gold;Doppler,120,gold
Huntsman Knife:Safari Mesh,80,gold;Case Hardened,150,gold;Doppler,210,gold
Falchion Knife:Safari Mesh,45,gold;Case Hardened,85,gold;Doppler,120,gold
Shadow Daggers:Safari Mesh,45,gold;Slaughter,110,gold
Bowie Knife:Safari Mesh,150,gold;Case Hardened,260,gold
Stiletto Knife:Forest DDPAT,230,gold;Doppler,500,gold
Talon Knife:Case Hardened,380,gold;Doppler,530,gold;Marble Fade,950,gold
Ursus Knife:Forest DDPAT,210,gold;Slaughter,450,gold
Skeleton Knife:Forest DDPAT,400,gold;Fade,1300,gold
Navaja Knife:Safari Mesh,110,gold
Classic Knife:Safari Mesh,260,gold
Paracord Knife:Safari Mesh,230,gold
Sport Gloves:Arid,460,gold;Slingshot,520,gold;Omega,1250,gold;Pandora's Box,3800,gold;Vice,5200,gold
Driver Gloves:Convoy,260,gold;Lunar Weave,300,gold;Diamondback,650,gold;King Snake,1250,gold;Crimson Weave,2200,gold
Hand Wraps:Spruce DDPAT,190,gold;Badlands,280,gold;Slaughter,540,gold;Cobalt Skulls,1600,gold
Moto Gloves:Eclipse,170,gold;Polygon,330,gold;Spearmint,480,gold;Boom!,650,gold
Specialist Gloves:Forest DDPAT,220,gold;Foundation,380,gold;Crimson Kimono,460,gold;Fade,1150,gold
Bloodhound Gloves:Charred,180,gold;Snakebite,240,gold;Bronzed,300,gold
Hydra Gloves:Mangrove,270,gold;Rattler,320,gold;Case Hardened,380,gold
Broken Fang Gloves:Yellow-banded,420,gold;Jade,650,gold
AK-47:Green Laminate,2,ind;Black Laminate,6,mil;Predator,2,ind;Safety Net,5,mil;Orbit Mk01,7,res;Rat Rod,8,res;Cartel,9,res;Emerald Pinstripe,8,res;Jet Set,9,res;Steel Delta,13,res;Panthera onca,12,res;Nightwish,16,cls;Head Shot,18,cls;The Empress,28,cls;Ice Coaled,20,cls;Legion of Anubis,24,cls;Aquamarine Revenge,32,cls;Fuel Injector,45,cls;Inheritance,60,cov;Case Hardened,70,cov;Gold Arabesque,520,cov
M4A4:Jungle Tiger,1,ind;Magnesium,1,ind;Tornado,3,mil;Zirka,3,mil;Daybreak,6,mil;Dragon King,6,res;Bullet Rain,14,res;Hellfire,16,cls;Cyber Security,12,res;Spider Lily,10,res;In Living Color,26,cls;Royal Paladin,20,cls;X-Ray,8,res;Temukau,45,cov;Etch Lord,8,res;Poseidon,180,cov
M4A1-S:Briefing,2,ind;Basilisk,3,mil;Flashback,3,mil;Mecha Industries,10,res;Master Piece,14,res;Hot Rod,18,res;Leaded Glass,8,res;Player Two,22,cls;Control Panel,16,cls;Imminent Danger,10,res;Night Terror,9,res;Welcome to the Jungle,60,cov;Icarus Fell,95,cov;Dark Water,3,mil;Bright Water,4,mil
Galil AR:Orange DDPAT,0.4,ww;Winter Forest,0.5,ww;Tuxedo,1,ind;Rocket Pop,3,mil;Firefight,3,mil;Crimson Tsunami,5,res;Connexion,4,res;Akoben,7,cls;Signal,6,res
FAMAS:Sergeant,3,mil;Neural Net,4,mil;Valence,4,res;Styx,6,res;Survivor Z,3,mil;Macabre,7,res;Rapid Eye Movement,12,cls;Crypsis,4,mil
AUG:Wings,3,mil;Hot Rod,6,res;Radiation Hazard,3,mil;Fleet Flock,5,mil;Ricochet,4,res;Death by Puppy,12,cls;Aristocrat,5,res;Momentum,8,res;Amber Slipstream,10,cls
SG 553:Danger Close,3,mil;Tornado,2,mil;Ultraviolet,2,ind;Triarch,5,res;Aerial,4,mil;Atlas,6,res;Bulldozer,2,mil;Damascus Steel,2,mil;Barricade,3,mil
AWP:Elite Build,3,mil;Worm God,2,ind;Graphite,12,res;Fever Dream,10,res;Oni Taiji,45,cov;Wildfire,38,cls;Mortis,12,res;Sun in Leo,6,res;Exoskeleton,4,mil;Pink DDPAT,10,res;POP AWP,15,res;Chromatic Aberration,25,cls;PAW,18,cls;Duality,8,res;Silk Tiger,28,cls;Desert Hydra,700,cov;Medusa,1500,cov
SSG 08:Acid Fade,5,res;Slashed,2,ind;Mayan Dreams,4,mil;Necropos,6,res;Detour,6,res;Turbo Peek,8,res;Orange Filigree,5,res;Tropical Storm,7,res;Threat Detected,4,mil
SCAR-20:Storm,0.2,ww;Powercore,2,mil;Splash Jam,2,mil;Grotto,3,mil;Crimson Web,4,res;Blueprint,5,res;Enforcer,8,res;Magna Carta,12,cls
G3SG1:Orange Kimono,2,mil;Orange Crash,2,mil;Safari Mesh,0.2,ww;The Executioner,9,res;VariCamo,0.3,ww;Green Apple,0.3,ind;Ventilator,3,mil;High Seas,4,res
Glock-18:Dragon Tattoo,9,res;Royal Legion,3,mil;Reactor,3,mil;Weasel,4,mil;Vogue,6,res;Gamma Doppler,45,cls;Off World,4,mil;Snack Attack,16,cls;Neo-Noir,12,res;Ironwork,2,mil;Franklin,5,res;Synth Leaf,6,res
USP-S:Blueprint,4,mil;Serum,5,mil;Torque,3,mil;Stainless,3,mil;Road Rash,4,mil;Flashback,3,mil;Cyrex,5,res;The Traitor,8,res;Ticket to Hell,6,res;Monster Mashup,5,mil;Black Lotus,12,res;Jawbreaker,10,res
P2000:Ocean Foam,3,res;Imperial Dragon,6,res;Ivory,2,ind;Pulse,3,mil;Woodsman,3,mil;Handgun,3,mil;Oceanic,4,res;Obsidian,4,res;Wicked Sick,5,res;Turf,1,ind
P250:Wingshot,5,mil;Undertow,4,mil;Valence,3,mil;Ripple,3,res;Visions,3,res;Cyber Shell,6,res;Verdigris,3,mil;Steel Disruption,4,mil;Contamination,6,res;See Ya Later,10,cls;Inferno,2,ind;Bone Mask,0.3,ww;Facility Draft,1,ind
Desert Eagle:Night,0.4,ww;Mudder,0.3,ww;Meteorite,2,ind;Naga,2,ind;Directive,3,mil;Crimson Web,6,res;Golden Koi,10,res;Heirloom,8,res;Code Red,25,cls;Trigger Discipline,12,res;Light Rail,10,res;Ocean Drive,18,cls;Mecha Industries,15,res
Five-SeveN:Hot Shot,1,ind;Orange Peel,1,ind;Fowl Play,5,mil;Nightshade,5,mil;Case Hardened,10,res;Triumvirate,6,res;Retrobution,8,res;Kami,3,mil;Violent Daimyo,4,mil;Fairy Tale,15,cls;Buddy,5,mil
Tec-9:Nuclear Threat,4,mil;Toxic,0.5,ind;Bamboo Forest,1,ind;Titanium Bit,4,mil;Avalanche,5,mil;Decimator,6,res;Re-Entry,5,mil;Blue Titanium,4,mil;Ice Cap,4,mil;Cut Out,5,res;Rebel,3,mil
CZ75-Auto:Tuxedo,0.8,ind;Chalice,2,mil;Poison Dart,3,mil;Pole Position,3,mil;Xiangliu,5,res;Yellow Jacket,3,mil;Red Astor,4,mil;Emerald Quartz,3,mil;Twist,1,ind;Syndicate,4,mil;Eco,3,mil
R8 Revolver:Crimson Web,4,res;Bone Mask,0.4,ww;Amber Fade,3,mil;Survivalist,2,mil;Skull Crusher,3,mil;Grip,4,res;Memento,3,mil;Canal Spray,2,ind
Dual Berettas:Urban Shock,2,mil;Melondrama,3,mil;Retribution,4,mil;Duelist,4,res;Dualing Dragons,5,res;Hemoglobin,1,ind;Panther,2,ind;Stained,0.8,ww;Cartel,3,mil;Demolition,3,mil;Moon in Libra,3,mil;Shred,3,mil;Ventilators,3,mil
MP9:Rose Iron,3,mil;Setting Sun,4,mil;Hypnotic,4,mil;Pandora's Box,6,res;Ruby Poison Dart,3,mil;Deadly Poison,3,mil;Dart,2,ind;Orange Peel,1,ind;Bioleak,2,mil;Mount Fuji,5,res;Food Chain,6,res;Goo,1,ind;Starlight Protector,12,cls;Featherweight,4,mil;Dry Season,1,ind
MAC-10:Last Dive,5,res;Graven,6,res;Tatter,2,mil;Pipe Down,3,mil;Allure,6,res;Fade,10,res;Oceanic,3,mil;Lapis Gator,4,mil;Ultraviolet,2,ind;Amber Fade,2,mil;Disco Tech,4,res;Toybox,3,mil;Monkeyflage,2,mil
MP7:Orange Peel,1,ind;Anodized Navy,1,ind;Impire,3,mil;Mischief,6,res;Teal Blossom,3,mil;Urban Hazard,2,ind;Special Delivery,3,mil;Ocean Cyan,3,mil;Abyssal Apparition,5,res;Neon Ply,4,res;Scorched,0.4,ww
MP5-SD:Agent,1,ind;Autumn Twilight,3,mil;Condition Zero,2,mil;Dirt Drop,2,mil;Kitbash,3,mil;Acid Wash,3,mil;Bamboozle,3,mil;Desert Strike,3,mil;Nitro,1,ind;Oxide Oasis,3,mil;Co-Processor,3,mil;Liquidation,4,res
UMP-45:Corporal,1,ind;Bone Pile,3,mil;Delusion,3,mil;Exposure,3,mil;Grand Prix,4,res;Metal Flowers,3,mil;Plastique,6,res;Riot,4,res;Briefing,3,mil;Gold Bismuth,5,res;Minotaur's Labyrinth,10,cls;Moonrise,5,res;Crime Scene,2,mil
P90:Leather,0.4,ind;Elite Build,2,mil;Blind Spot,1,ind;Cold Blooded,5,res;Desert Warfare,3,mil;Shapewood,4,res;Grim,4,mil;Baroque Red,2,mil;Sunset Lily,4,res;Facility Negative,2,mil;Fallout Warning,3,mil;Vent Rush,6,res;Tiger Pit,3,mil;Nostalgia,5,res
PP-Bizon:Antique,2,mil;Blue Streak,2,mil;Carbon Fiber,0.4,ind;Cobalt Halftone,3,mil;Harvester,3,mil;High Roller,5,res;Night Riot,5,res;Osiris,4,mil;Photic Zone,3,mil;Rust Coat,0.5,ww;Seabird,1,ind;Embargo,2,mil;Jungle Slipstream,3,mil;Space Cat,5,res;Modern Hunter,3,mil
Nova:Walnut,0.5,ind;Graphite,2,mil;Ranger Camo,1,ind;Koi,3,mil;Gila,3,mil;Wild Six,4,mil;Rising Skull,4,res;Toy Soldier,4,mil;Mandrel,2,ind;Windblown,1,ind;Clear Polymer,5,res;Ghost Camo,3,mil;Plume,4,mil;Tempest,5,res;Wood Fired,6,res
XM1014:Ziggy,3,mil;Teclu Burner,4,res;Red Python,2,ind;Quicksilver,2,mil;Heaven Guard,2,mil;Scumbria,3,mil;Fallout Warning,2,mil;Elegant Vines,2,mil;Slipstream,6,res;Entombed,4,res;Bone Machine,3,mil;Atmosphere,3,mil;CaliCamo,1,ind;Blaze Orange,0.5,ind;Grassland,0.3,ww
MAG-7:Swag-7,3,mil;Counter Terrace,3,mil;Cobalt Core,2,mil;Hard Water,2,ind;Firestarter,4,res;Praetorian,5,res;Rust Coat,0.5,ww;Silver,0.4,ind;Insomnia,3,mil;Monster Call,4,mil;Justice,4,res;Popdog,3,mil;Core Breach,3,mil;Petroglyph,3,mil;Sonar,3,mil
Sawed-Off:Copper,0.3,ind;Origami,1,mil;Orange DDPAT,0.3,ww;Rust Coat,0.4,ww;Amber Fade,2,mil;First Class,1,mil;Full Stop,3,mil;Mosaico,2,mil;Serenity,3,mil;Wasteland Princess,4,res;Zander,3,mil;Devourer,4,res;Limelight,3,mil;Analog Input,3,mil;Black Sand,2,mil
M249:Contrast Spray,0.3,ww;Magma,2,mil;Spectre,2,mil;Gator Mesh,0.5,ind;Impact Drill,3,mil;System Lock,3,mil;Warbird,5,res;Deep Relief,3,mil;Midnight Palm,3,mil;Aztec,2,mil;O.S.I.P.R.,4,mil;Downtown,3,mil;Humidor,5,res;Blizzard Marbleized,3,mil
Negev:Anodized Navy,1,ind;Man-o'-war,2,mil;Palm,1,ind;CaliCamo,0.5,ind;Bratatat,3,mil;Desert-Strike,3,mil;Loudmouth,3,mil;Dazzle,2,mil;Terrain,2,mil;Ultralight,4,res;Prototype,3,mil;Phoenix Stencil,3,mil
Karambit:Blue Steel,320,gold;Night,360,gold;Stained,340,gold;Crimson Web,720,gold;Urban Masked,300,gold;Scorched,290,gold;Boreal Forest,300,gold;Rust Coat,280,gold;Damascus Steel,430,gold;Ultraviolet,380,gold;Gamma Doppler,820,gold;Lore,1100,gold;Autotronic,1000,gold;Freehand,1500,gold;Bright Water,480,gold;Black Laminate,1100,gold
M9 Bayonet:Blue Steel,230,gold;Night,260,gold;Stained,240,gold;Crimson Web,560,gold;Urban Masked,200,gold;Scorched,195,gold;Boreal Forest,205,gold;Rust Coat,190,gold;Damascus Steel,300,gold;Ultraviolet,260,gold;Gamma Doppler,700,gold;Lore,950,gold;Autotronic,850,gold;Tiger Tooth,600,gold;Freehand,1100,gold;Bright Water,350,gold;Black Laminate,900,gold
Bayonet:Blue Steel,150,gold;Night,170,gold;Stained,150,gold;Crimson Web,350,gold;Urban Masked,115,gold;Scorched,115,gold;Boreal Forest,125,gold;Rust Coat,110,gold;Damascus Steel,200,gold;Ultraviolet,170,gold;Gamma Doppler,430,gold;Lore,600,gold;Autotronic,520,gold;Tiger Tooth,380,gold;Fade,500,gold;Bright Water,230,gold;Black Laminate,520,gold
Butterfly Knife:Safari Mesh,300,gold;Blue Steel,380,gold;Night,420,gold;Stained,360,gold;Crimson Web,1200,gold;Urban Masked,320,gold;Scorched,300,gold;Boreal Forest,320,gold;Rust Coat,290,gold;Damascus Steel,520,gold;Ultraviolet,430,gold;Gamma Doppler,1000,gold;Lore,1800,gold;Autotronic,1500,gold;Fade,1700,gold;Bright Water,700,gold;Black Laminate,1300,gold;Freehand,1300,gold
Flip Knife:Forest DDPAT,100,gold;Blue Steel,120,gold;Night,130,gold;Stained,115,gold;Crimson Web,230,gold;Urban Masked,100,gold;Scorched,95,gold;Boreal Forest,100,gold;Slaughter,200,gold;Marble Fade,420,gold;Tiger Tooth,280,gold;Ultraviolet,130,gold;Damascus Steel,160,gold;Gamma Doppler,280,gold;Lore,380,gold;Autotronic,350,gold;Bright Water,150,gold;Black Laminate,320,gold;Freehand,300,gold;Rust Coat,95,gold
Gut Knife:Forest DDPAT,50,gold;Blue Steel,60,gold;Night,65,gold;Stained,55,gold;Crimson Web,110,gold;Urban Masked,50,gold;Scorched,48,gold;Boreal Forest,52,gold;Slaughter,95,gold;Marble Fade,170,gold;Tiger Tooth,130,gold;Fade,200,gold;Damascus Steel,75,gold;Ultraviolet,65,gold;Gamma Doppler,150,gold;Lore,200,gold;Autotronic,180,gold;Bright Water,70,gold;Black Laminate,180,gold;Freehand,150,gold;Rust Coat,48,gold
Huntsman Knife:Forest DDPAT,85,gold;Blue Steel,100,gold;Night,110,gold;Stained,95,gold;Crimson Web,230,gold;Urban Masked,85,gold;Scorched,82,gold;Boreal Forest,90,gold;Slaughter,190,gold;Marble Fade,400,gold;Tiger Tooth,280,gold;Fade,400,gold;Damascus Steel,140,gold;Ultraviolet,110,gold;Gamma Doppler,260,gold;Lore,400,gold;Autotronic,350,gold;Bright Water,140,gold;Black Laminate,350,gold;Freehand,300,gold;Rust Coat,85,gold
Falchion Knife:Forest DDPAT,50,gold;Slaughter,100,gold;Marble Fade,200,gold;Tiger Tooth,150,gold;Fade,220,gold;Blue Steel,70,gold;Night,75,gold;Stained,62,gold;Crimson Web,140,gold
Shadow Daggers:Forest DDPAT,48,gold;Case Hardened,95,gold;Doppler,150,gold;Fade,230,gold;Tiger Tooth,160,gold;Marble Fade,200,gold;Blue Steel,62,gold;Night,66,gold
Bowie Knife:Forest DDPAT,160,gold;Doppler,320,gold;Slaughter,350,gold;Fade,550,gold;Marble Fade,550,gold;Tiger Tooth,420,gold;Blue Steel,200,gold;Night,220,gold
Stiletto Knife:Safari Mesh,220,gold;Case Hardened,420,gold;Slaughter,520,gold;Fade,800,gold;Marble Fade,800,gold;Tiger Tooth,600,gold;Blue Steel,280,gold
Talon Knife:Safari Mesh,300,gold;Forest DDPAT,310,gold;Slaughter,520,gold;Fade,800,gold;Tiger Tooth,600,gold;Blue Steel,380,gold;Night,400,gold
Ursus Knife:Safari Mesh,200,gold;Case Hardened,330,gold;Doppler,420,gold;Fade,600,gold;Marble Fade,600,gold;Tiger Tooth,430,gold;Blue Steel,260,gold
Skeleton Knife:Safari Mesh,380,gold;Case Hardened,600,gold;Slaughter,800,gold;Doppler,900,gold;Marble Fade,1200,gold;Tiger Tooth,1100,gold
Navaja Knife:Forest DDPAT,115,gold;Case Hardened,200,gold;Doppler,260,gold;Slaughter,250,gold;Fade,340,gold;Marble Fade,320,gold;Tiger Tooth,260,gold
Classic Knife:Forest DDPAT,270,gold;Case Hardened,400,gold;Slaughter,450,gold;Fade,600,gold;Stained,330,gold;Blue Steel,320,gold
Paracord Knife:Forest DDPAT,240,gold;Case Hardened,350,gold;Slaughter,380,gold;Fade,520,gold;Stained,270,gold;Blue Steel,270,gold
Nomad Knife:Safari Mesh,230,gold;Forest DDPAT,240,gold;Case Hardened,380,gold;Slaughter,400,gold;Fade,550,gold;Stained,260,gold
Survival Knife:Safari Mesh,200,gold;Forest DDPAT,210,gold;Case Hardened,330,gold;Slaughter,360,gold;Fade,480,gold;Stained,230,gold
Sport Gloves:Hedge Maze,2200,gold;Superconductor,1500,gold;Nocts,900,gold;Amphibious,650,gold;Bronze Morph,480,gold;Big Game,2800,gold;Scarlet Shamagh,430,gold
Driver Gloves:Overtake,400,gold;Racing Green,450,gold;Black Tie,550,gold;Snow Leopard,1300,gold;Rezan the Red,350,gold;Queen Jaguar,650,gold;Imperial Plaid,950,gold
Moto Gloves:Cool Mint,750,gold;Turtle,420,gold;POW!,220,gold;Transport,240,gold;Finish Line,380,gold;Blood Pressure,480,gold;Smoke Out,350,gold
Specialist Gloves:Emerald Web,1900,gold;Lt. Commander,420,gold;Mogul,280,gold;Buckshot,320,gold;Tiger Strike,360,gold;Field Agent,460,gold;Marble Fade,2100,gold;Crimson Web,1600,gold
Hand Wraps:Constrictor,210,gold;Leather,260,gold;CAUTION!,250,gold;Duct Tape,270,gold;Overprint,520,gold;Giraffe,720,gold;Arboreal,400,gold;Desert Shamagh,180,gold
Bloodhound Gloves:Guerrilla,720,gold
Hydra Gloves:Emerald,1300,gold
Broken Fang Gloves:Needle Point,540,gold;Unhinged,400,gold
`;
const TYPES = {
  rifle:["AK-47","M4A4","M4A1-S","Galil AR","FAMAS","AUG","SG 553"],
  sniper:["AWP","SSG 08","SCAR-20","G3SG1"],
  pistol:["Glock-18","USP-S","P2000","P250","Desert Eagle","Five-SeveN","Tec-9","CZ75-Auto","R8 Revolver","Dual Berettas"],
  smg:["MP9","MAC-10","MP7","MP5-SD","UMP-45","P90","PP-Bizon"],
  shotgun:["Nova","XM1014","MAG-7","Sawed-Off"],
  mg:["M249","Negev"],
  knife:["Karambit","M9 Bayonet","Bayonet","Butterfly Knife","Flip Knife","Gut Knife","Huntsman Knife","Falchion Knife","Shadow Daggers","Bowie Knife","Stiletto Knife","Talon Knife","Ursus Knife","Skeleton Knife","Navaja Knife","Classic Knife","Paracord Knife","Nomad Knife","Survival Knife"],
  gloves:["Sport Gloves","Driver Gloves","Hand Wraps","Moto Gloves","Specialist Gloves","Bloodhound Gloves","Hydra Gloves","Broken Fang Gloves"]
};
const typeOf = {};
Object.entries(TYPES).forEach(([ty, ws]) => ws.forEach(w => typeOf[w] = ty));
const hue = s => { let h = 0; for(const ch of s) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };

// ===== Каталог: унікальні скіни × стани зносу (+ StatTrak™) =====
const CATALOG = [], SEEN = new Set(), BASE = [];
RAW.trim().split("\n").forEach(line => {
  const i = line.indexOf(":"), w = line.slice(0, i);
  line.slice(i + 1).split(";").forEach(e => {
    const [s, p, r] = e.split(","), base = w + " | " + s;
    if(SEEN.has(base)) return;
    SEEN.add(base); BASE.push([base, +p, r, typeOf[w]]);
  });
});
// CATALOG: [назва, ціна, рідкість, категорія, колір1, колір2, свій URL, базова назва, знос, StatTrak]
const WEARS = [["FN","Factory New",1.35], ["FT","Field-Tested",1], ["BS","Battle-Scarred",0.65]];
const r2 = x => Math.max(0.03, Math.round(x * 100) / 100);
function addSkin(base, price, rar, type, wear, st){
  const h = hue(base);
  CATALOG.push([(st ? "StatTrak™ " : "") + base + " (" + wear[1] + ")", r2(price * wear[2] * (st ? 1.6 : 1)), rar, type,
    `hsl(${h},75%,58%)`, `hsl(${(h + 50) % 360},60%,28%)`, "", base, wear[0], st ? 1 : 0]);
}
BASE.forEach(b => WEARS.forEach(w => addSkin(b[0], b[1], b[2], b[3], w, false)));
[...BASE].filter(b => b[3] !== "gloves").sort((a, b) => b[1] - a[1])
  .slice(0, Math.max(0, SKIN_TARGET - CATALOG.length)).forEach(b => addSkin(b[0], b[1], b[2], b[3], WEARS[1], true));
// ===== Унікальні ціни: у всіх 3000 скінів ціна різна, найдорожчий коштує 500 000 =====
const MAX_PRICE = 500000, KEEP_UNDER = 40;   // до 40 ціни майже реалістичні, вище розтягуються до 500 000
(function uniquePrices(){
  const order = CATALOG.map((_, i) => i)
    .sort((a, b) => CATALOG[a][1] - CATALOG[b][1] || (CATALOG[a][0] < CATALOG[b][0] ? -1 : 1));
  const top = CATALOG[order[order.length - 1]][1];
  const k = Math.log(MAX_PRICE / KEEP_UNDER) / Math.log(top / KEEP_UNDER);
  let prev = 0;                                          // ціна в копійках
  order.forEach(i => {
    const raw = CATALOG[i][1], p = raw <= KEEP_UNDER ? raw : KEEP_UNDER * Math.pow(raw / KEEP_UNDER, k);
    let cents = Math.round(p * 100);
    if(cents >= 100000) cents = Math.round(cents / 100) * 100;   // від 1000 без копійок
    if(cents <= prev) cents = prev + (prev >= 100000 ? 100 : 1); // порядок цін зберігається, збіги зсуваються
    CATALOG[i][1] = cents / 100; prev = cents;
  });
})();
const NAMEMAP = new Map(CATALOG.map(c => [c[0], c]));
const byName = n => NAMEMAP.get(n);
const fixName = n => NAMEMAP.has(n) ? n : NAMEMAP.has(n + " (Field-Tested)") ? n + " (Field-Tested)" : n;
const wearName = code => (WEARS.find(w => w[0] === code) || ["", ""])[1];
const RANGES = {all:[0,1e9], cheap:[0,10], mid:[10,100], high:[100,1000], top:[1000,10000], ultra:[10000,100000], mega:[100000,1e9]};
const RC = {ww:"#b0c3d9", ind:"#5e98d9", mil:"#4b69ff", res:"#8847ff", cls:"#d32ce6", cov:"#eb4b4b", gold:"#e4ae39"};

// ===== Кейси: до 150 штук. Ціна = середня вартість вмісту / 0.9; шанс залежить від рідкості =====
const P = (lo, hi) => c => c[1] >= lo && c[1] < hi;
const T = (ts, lo = 0, hi = 1e9) => c => ts.includes(c[3]) && c[1] >= lo && c[1] < hi;
const WP = ws => c => ws.includes(c[7].split(" | ")[0]);
const K = (ks, lo = 0, hi = 1e9) => c => c[1] >= lo && c[1] < hi && ks.some(k => c[0].includes(k));
const R = rs => c => rs.includes(c[2]);
const CASE_DEFS = [
  ["starter","Starter Crate","📦","#8aa0b8",P(0,5)],
  ["recruit","Recruit Case","🪖","#5e98d9",P(0,15)],
  ["soldier","Soldier Case","🎖️","#4b69ff",P(5,40)],
  ["veteran","Veteran Case","🛡️","#6a5acd",P(20,100)],
  ["elite","Elite Case","⭐","#8847ff",P(60,250)],
  ["master","Master Case","👑","#d32ce6",P(150,700)],
  ["legend","Legend Case","🔥","#eb4b4b",P(500,2500)],
  ["mythic","Mythic Case","💎","#e4ae39",P(1500,10000)],
  ["rifle","Rifle Case","🔫","#3e8f5f",T(["rifle"],0,40)],
  ["assault","Assault Case","💥","#2f9e8f",T(["rifle"],30,300)],
  ["rifleelite","Rifle Elite","🏆","#c0262d",T(["rifle"],150)],
  ["sniper","Sniper Case","🎯","#3a78ff",T(["sniper"],0,50)],
  ["sniperelite","Sniper Elite","🔭","#1f4fd8",T(["sniper"],40)],
  ["pistol","Pistol Case","🔫","#d9a441",T(["pistol"],0,15)],
  ["pistolelite","Pistol Elite","🌟","#ff7a1a",T(["pistol"],10)],
  ["smg","SMG Case","⚡","#ff3ea5",T(["smg"])],
  ["heavy","Heavy Case","🛡️","#8a98a8",T(["shotgun","mg"])],
  ["knife","Knife Case","🔪","#b0c3d9",T(["knife"],0,300)],
  ["knifeelite","Knife Elite","🗡️","#e4ae39",T(["knife"],300)],
  ["glove","Glove Case","🧤","#d63a8c",T(["gloves"],0,400)],
  ["gloveelite","Glove Elite","✨","#9a4aff",T(["gloves"],400)],
  ["ak","AK-47 Case","🔥","#c0262d",WP(["AK-47"])],
  ["awp","AWP Case","🐉","#3d9a5a",WP(["AWP"])],
  ["m4","M4 Case","⚙️","#4a6a9a",WP(["M4A4","M4A1-S"])],
  ["gu","Glock & USP Case","🔱","#5aa84a",WP(["Glock-18","USP-S","P2000"])],
  ["hp","Heavy Pistol Case","🔰","#ff9a3d",WP(["Desert Eagle","R8 Revolver","Five-SeveN","Tec-9","CZ75-Auto","Dual Berettas"])],
  ["fade","Fade Case","🌈","#ff6a9a",K(["Fade","Doppler","Marble","Tiger"])],
  ["asiimov","Asiimov Case","🚀","#e8731a",K(["Asiimov","Hyper Beast","Neon","Printstream","Vulcan","Bloodsport","Neo-Noir"])],
  ["mixed","Mixed Case","🎲","#6ad7ff",P(10,300)],
  ["jackpot","Jackpot Case","🎰","#ffd23f",P(0,1e9)],
  ["cheap","Penny Case","🪙","#9fb3a6",P(0,3)],
  ["lucky","Lucky Case","🍀","#3ddc84",P(0,60)],
  ["industrial","Industrial Case","🏭","#5e98d9",R(["ww","ind"])],
  ["milspec","Mil-Spec Case","🔷","#4b69ff",R(["mil"])],
  ["restricted","Restricted Case","🟣","#8847ff",R(["res"])],
  ["classified","Classified Case","🌸","#d32ce6",R(["cls"])],
  ["covert","Covert Case","🔴","#eb4b4b",R(["cov"])],
  ["vip","VIP Case","💠","#2ee6c8",P(300,1e9)],
  ["usp","USP-S Case","🔫","#4a6a9a",WP(["USP-S"])],
  ["glock","Glock Case","🔫","#7fc15a",WP(["Glock-18"])],
  ["deagle","Deagle Case","🦅","#ff9a3d",WP(["Desert Eagle"])],
  ["smgelite","SMG Elite","⚡","#ff3ea5",T(["smg"],12)],
  ["shotgun","Shotgun Case","💣","#c9a227",T(["shotgun"])],
  ["mg","Machine Gun Case","🔥","#8a98a8",T(["mg"])],
  ["karambit","Karambit Case","🔪","#7a2cff",WP(["Karambit"])],
  ["butterfly","Butterfly Case","🦋","#f2c14e",WP(["Butterfly Knife"])],
  ["m9","M9 Bayonet Case","🗡️","#2f6bff",WP(["M9 Bayonet"])],
  ["doppler","Doppler Case","🌌","#b43bff",K(["Doppler"])],
  ["slaughter","Crimson Case","🩸","#d8452e",K(["Slaughter","Crimson","Case Hardened"])],
  ["neon","Neon Case","💡","#00d5ff",K(["Neon","Hyper Beast","Cyber","Electric","Lightning"])],
  ["dragon","Dragon Case","🐲","#3d9a5a",K(["Dragon","Hydra","Serpent","Medusa"])],
  ["tiger","Wild Case","🐯","#e8731a",K(["Tiger","Jaguar","Panthera","Bengal","Lion","Wolf"])],
  ["ocean","Ocean Case","🌊","#3aa6d8",K(["Water","Ocean","Sea","Man-o'-war","Poseidon","Aqua"])],
  ["toxic","Toxic Case","☢️","#9be22f",K(["Toxic","Poison","Radiation","Hazard","Nuclear","Acid"])],
  ["sportdrv","Sport & Driver Case","🧤","#d63a8c",WP(["Sport Gloves","Driver Gloves"])],
  ["motowrap","Moto & Wraps Case","🏍️","#ff7a1a",WP(["Moto Gloves","Hand Wraps"])]
];
const usedCase = new Set(CASE_DEFS.map(d => d[1]));
const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, "");
const hsl = s => `hsl(${hue(s)},65%,55%)`;
function addCase(id, name, emoji, color, fn){
  if(CASE_DEFS.length >= CASE_LIMIT || usedCase.has(name)) return;
  if(CATALOG.filter(fn).length < 8) return;
  usedCase.add(name); CASE_DEFS.push([id, name, emoji, color, fn]);
}
[["Camo Case","🌿",["Forest","DDPAT","Camo","Mesh","Safari","Jungle"]],
 ["Desert Case","🏜️",["Desert","Sand","Dune","Dust"]],
 ["Fire Case","🔥",["Fire","Blaze","Hellfire","Flame","Inferno","Vulcan","Heat","Magma","Redline"]],
 ["Ice Case","❄️",["Ice","Frozen","Arctic","Winter","Polar","Whiteout","Blizzard","Frost"]],
 ["Cyber Case","🤖",["Cyber","Neo-Noir","Synth","Circuit","Printstream","Asiimov","Neural","Laser"]],
 ["Dark Case","🌑",["Night","Black","Shadow","Dark","Death","Skull","Doom","Grim"]],
 ["Royal Case","👑",["Gold","Royal","Emperor","Empress","King","Queen","Imperial","Paladin"]],
 ["Nature Case","🍃",["Leaf","Lotus","Bamboo","Koi","Orchid","Wild","Rose","Blossom"]],
 ["Tech Case","⚙️",["Carbon","Titanium","Cobalt","Steel","Alloy","Module","Mecha","Reactor","Silver","Chrome"]],
 ["Samurai Case","🏯",["Daimyo","Kami","Oni","Kimono","Fuji","Shogun","Sakura"]],
 ["Space Case","🚀",["Galaxy","Nebula","Space","Moon","Star","Supernova","Orbit","Cosmic","Comet"]],
 ["Blood Case","🩸",["Blood","Scarlet","Ruby","Carnage"]]
].forEach(([n, e, ks]) => addCase("g_" + slug(n), n, e, hsl(n), K(ks)));
addCase("g_fn", "Factory New Case", "✨", "#5bf0a0", c => c[8] === "FN");
addCase("g_ft", "Field-Tested Case", "🛠️", "#c6ff5a", c => c[8] === "FT" && !c[9]);
addCase("g_bs", "Battle-Scarred Case", "🪖", "#8d9a8a", c => c[8] === "BS");
addCase("g_st", "StatTrak™ Case", "📊", "#ff9a3d", c => c[9] === 1);
const BANDS = [["Bronze",0,1],["Copper",1,3],["Iron",3,6],["Steel",6,12],["Silver",12,25],["Platinum",25,50],["Titanium",50,100],
  ["Emerald",100,200],["Sapphire",200,400],["Ruby",400,800],["Amethyst",800,1600],["Diamond",1600,3200],["Obsidian",3200,8000],
  ["Onyx",8000,20000],["Jade",20000,50000],["Mythril",50000,120000],["Cosmic",120000,1e9]];
BANDS.forEach(([n, lo, hi]) => addCase("g_b" + slug(n), n + " Case", "💎", hsl(n), P(lo, hi)));
const TYPE_EMOJI = {rifle:"🔫", sniper:"🎯", pistol:"🔫", smg:"⚡", shotgun:"💣", mg:"🔥", knife:"🔪", gloves:"🧤"};
Object.entries(TYPES).forEach(([ty, ws]) => ws.forEach(w => addCase("g_w" + slug(w), w + " Case", TYPE_EMOJI[ty], hsl(w), WP([w]))));
const CAT_NAME = {rifle:"Rifle", sniper:"Sniper", pistol:"Pistol", smg:"SMG", shotgun:"Shotgun", mg:"MG", knife:"Knife", gloves:"Glove"};
const CAT_CUT = {knife:[150,500], gloves:[400,1000]};
Object.keys(TYPES).forEach(ty => {
  const [a, b] = CAT_CUT[ty] || [20, 200];
  [["Budget", 0, a], ["Standard", a, b], ["Premium", b, 1e9]].forEach(([n, lo, hi]) =>
    addCase("g_t" + ty + n, `${CAT_NAME[ty]} ${n} Case`, TYPE_EMOJI[ty], hsl(ty + n), T([ty], lo, hi)));
});
const RW = {ww:40, ind:30, mil:20, res:6, cls:3, cov:0.8, gold:0.3};    // шанс випадіння за рідкістю
const CASES = CASE_DEFS.map(([id, name, emoji, color, fn]) => {
  const pool = CATALOG.filter(fn), sums = {};
  pool.forEach(c => sums[c[2]] = (sums[c[2]] || 0) + Math.pow(c[1], -0.5));
  const raw = pool.map(c => RW[c[2]] * Math.pow(c[1], -0.5) / sums[c[2]]);
  const tot = raw.reduce((a, b) => a + b, 0), ws = raw.map(w => w / tot);
  const ev = pool.reduce((s, c, i) => s + c[1] * ws[i], 0);
  let price = ev / 0.9;                                                    // повернення ~90%
  price = price < 10 ? Math.max(0.5, Math.round(price * 100) / 100) : Math.round(price);
  return {id, name, emoji, color, items:pool.map(c => c[0]), ws, price,
    lo:Math.min(...pool.map(c => c[1])), hi:Math.max(...pool.map(c => c[1]))};
});
function crateSvg(color, emoji){
  return `<svg viewBox="0 0 100 80" aria-hidden="true"><rect x="12" y="28" width="76" height="46" rx="5" fill="${color}"/>
    <rect x="12" y="52" width="76" height="22" rx="5" fill="#000" opacity=".28"/>
    <rect x="7" y="14" width="86" height="20" rx="5" fill="${color}"/><rect x="7" y="14" width="86" height="20" rx="5" fill="#fff" opacity=".18"/>
    <rect x="43" y="14" width="14" height="60" fill="#fff" opacity=".16"/><rect x="45" y="30" width="10" height="12" rx="2" fill="#c6ff5a"/>
    <text x="50" y="68" font-size="20" text-anchor="middle">${emoji}</text></svg>`;
}

// ===== Календар: нагороди =====
const ADV_SKINS = {7:"M4A4 | Evil Daimyo (Field-Tested)", 14:"AK-47 | Redline (Field-Tested)",
  21:"AWP | Neo-Noir (Field-Tested)", 28:"M4A4 | The Emperor (Field-Tested)"};
const ADV_LAST = "Gut Knife | Safari Mesh (Field-Tested)";
const daysInMonth = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth() + 1, 0).getDate(); };
function adventReward(d, dim){
  if(d === dim) return {skin:ADV_LAST, kind:"skin"};
  if(ADV_SKINS[d]) return {skin:ADV_SKINS[d], kind:"skin"};
  if(d % 5 === 0) return {coins:(5 + d) * 3, kind:"chest"};     // кожен 5-й день: скриня монет
  return {coins:5 + d, kind:"coins"};
}

// ===== Справжні картинки (публічне API ByMykel/CSGO-API), ключ — базова назва скіна =====
let IMG = {}; try{ IMG = JSON.parse(localStorage.getItem("upg_img3") || "{}"); }catch(e){}
const norm = s => s.replace(/^★\s*/, "").replace(/^(StatTrak™|Souvenir)\s*/, "").replace(/\s*\([^)]*\)\s*$/, "").trim().toLowerCase();
async function loadImages(){
  let ts = 0; try{ ts = +localStorage.getItem("upg_img3_t") || 0; }catch(e){}
  if(Date.now() - ts < 7 * 864e5 && BASE.some(b => IMG[b[0]])) return;     // не частіше разу на тиждень
  try{
    const list = await (await fetch("https://bymykel.github.io/CSGO-API/api/en/skins.json")).json();
    const m = {}; list.forEach(s => { if(s.image) m[norm(s.name)] = s.image; });
    BASE.forEach(b => { const u = m[norm(b[0])]; if(u) IMG[b[0]] = u; });
    try{ localStorage.setItem("upg_img3", JSON.stringify(IMG)); localStorage.setItem("upg_img3_t", String(Date.now())); }catch(e){}
    renderEverything();
  }catch(e){}   // без інтернету лишаються малюнки SVG
}
function picture(c){
  const u = c[6] || IMG[c[7]];
  return u ? `<img src="${u}" data-n="${esc(c[0])}" alt="" loading="lazy">` : svgIcon(c);
}
document.addEventListener("error", e => {      // якщо картинка не завантажилась, повертаємо SVG
  const i = e.target;
  if(i.tagName === "IMG" && i.dataset.n){
    const c = byName(i.dataset.n);
    if(c){ delete IMG[c[7]]; c[6] = ""; }
    renderEverything();
  }
}, true);

// ===== Стан =====
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt = n => n.toLocaleString(lang === "uk" ? "uk-UA" : "en-US", {maximumFractionDigits:2});
const nm = n => { const c = byName(n); return `<span style="color:${c ? RC[c[2]] : "#fff"}">${esc(n)}</span>`; };
const mon = () => { const d = new Date(); return d.getFullYear() + "-" + (d.getMonth() + 1); };

function fresh(){
  return {bal:START_BALANCE, uid:3, upg:0, wins:0, cases:0, feed:[], adv:{m:mon(), days:[]}, set:Object.assign({}, DEF),
    inv:[{id:1,n:"P250 | Sand Dune (Field-Tested)"},{id:2,n:"MP9 | Storm (Field-Tested)"},{id:3,n:"USP-S | Para Green (Field-Tested)"}]};
}
function load(){
  try{
    const s = JSON.parse(localStorage.getItem("upg_v4"));
    if(s){
      s.inv.forEach(i => i.n = fixName(i.n));              // старі збереження без стану зносу
      s.inv = s.inv.filter(i => byName(i.n));
      (s.feed || []).forEach(e => {
        if(e.item) e.item = fixName(e.item);
        if(e.stake) e.stake = e.stake.map(fixName);
        if(e.r && e.r.skin) e.r.skin = fixName(e.r.skin);
      });
      s.set = Object.assign({}, DEF, s.set);
      if(!s.adv || s.adv.m !== mon()) s.adv = {m:mon(), days:[]};
      s.uid = Math.max(s.uid || 0, ...s.inv.map(i => i.id));
      return s;
    }
  }catch(e){}
  return null;
}
function save(){ try{ localStorage.setItem("upg_v4", JSON.stringify(S)); }catch(e){} }

let S = load() || fresh();
let selInv = new Set(), target = null, balStake = 0, busy = false, curDeg = 0, lastDelta = 0, lastRes = null, spinCh = null;
let advPop = 0, advDay = new Date().getDate(), nextBonus = Date.now() + S.set.secs * 1000;
let duelSnap = null;                                  // знімок ставки й цілі під час та після крутки
const clearDuel = () => { duelSnap = null; };

const addBal = x => { S.bal = Math.round((S.bal + x) * 100) / 100; };
const addFeed = e => { e.ts = Date.now(); S.feed.unshift(e); S.feed.length = Math.min(S.feed.length, 30); };
function setRes(k, cls, x){ lastRes = {k, cls, x:x || ""}; showRes(); }
function showRes(){
  const r = $("res");
  if(!lastRes){ r.textContent = ""; r.className = "result"; return; }
  r.textContent = t(lastRes.k) + lastRes.x;
  r.className = "result " + lastRes.cls;
}
const skinsValue = () => S.inv.filter(i => selInv.has(i.id)).reduce((s, i) => s + byName(i.n)[1], 0);
const stakeValue = () => Math.round((skinsValue() + balStake) * 100) / 100;
function chance(){
  const sv = stakeValue();
  if(!target || sv <= 0) return 0;
  return Math.min(S.set.max, Math.round(sv / byName(target)[1] * S.set.edge * 100) / 100);
}
function pickNearest(want){                          // цільовий скін з ціною, найближчою до потрібної
  target = CATALOG.reduce((a, c) => Math.abs(Math.log(c[1] / want)) < Math.abs(Math.log(a[1] / want)) ? c : a)[0];
}

// ===== Звук (WebAudio, без файлів) =====
let AC = null;
function audio(){
  if(!S.set.sound) return null;
  try{
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    if(AC.state === "suspended") AC.resume();
  }catch(e){ return null; }
  return AC;
}
function beep(freq, dur, type, vol, delay, slide){
  const a = audio(); if(!a) return;
  const t0 = a.currentTime + (delay || 0), o = a.createOscillator(), g = a.createGain();
  o.type = type || "sine"; o.frequency.setValueAtTime(freq, t0);
  if(slide) o.frequency.exponentialRampToValueAtTime(slide, t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol || 0.15, t0 + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(a.destination); o.start(t0); o.stop(t0 + dur + 0.02);
}
const SFX = {
  tick(p){ beep(360 + 560 * p, 0.035, "square", 0.045); },       // p: 1 = швидко, 0 = повільно
  click(){ beep(520, 0.06, "triangle", 0.12, 0, 320); },
  coin(){ beep(988, 0.08, "sine", 0.1); beep(1319, 0.16, "sine", 0.1, 0.07); },
  win(){ [523, 659, 784, 1047].forEach((f, i) => beep(f, 0.28, "triangle", 0.16, i * 0.09)); beep(1568, 0.5, "sine", 0.1, 0.4); },
  lose(){ beep(220, 0.35, "sawtooth", 0.1, 0, 90); beep(165, 0.45, "sawtooth", 0.08, 0.15, 70); },
  drop(r){
    const n = {ww:1, ind:1, mil:2, res:3, cls:4, cov:5, gold:6}[r] || 1;
    for(let i = 0; i < n; i++) beep(440 * Math.pow(1.26, i), 0.22, "triangle", 0.14, i * 0.08);
  }
};
function renderToggles(){
  $("soundBtn").classList.toggle("on", S.set.sound);
  $("soundBtn").textContent = S.set.sound ? "🔊" : "🔇";
  $("fastBtn").classList.toggle("on", S.set.fast);
}
$("soundBtn").onclick = () => { S.set.sound = !S.set.sound; save(); renderToggles(); SFX.click(); };
$("fastBtn").onclick = () => { S.set.fast = !S.set.fast; save(); renderToggles(); };

// ===== Анімація в JS (щоб звук збігався з рисками), плавне уповільнення =====
let skipNow = false;
function animate(dur, onFrame){
  return new Promise(res => {
    const t0 = performance.now();
    skipNow = false;
    (function step(now){
      const x = skipNow ? 1 : Math.min(1, (now - t0) / dur);
      onFrame(1 - Math.pow(1 - x, 4), x);          // easeOutQuart
      x < 1 ? requestAnimationFrame(step) : res();
    })(t0);
  });
}
function flash(cls){
  const w = document.querySelector(".wheelbox");
  w.classList.remove("flash-win", "flash-lose"); void w.offsetWidth; w.classList.add("flash-" + cls);
}

// ===== Рендер: картки =====
function card(c, o){
  o = o || {};
  const name = (c[9] ? "ST™ " : "") + (c[7].split(" | ")[1] || c[7]);
  return `<div class="skin ${c[2]}${o.sel ? " sel" : ""}" data-n="${esc(c[0])}"${o.id ? ` data-id="${o.id}"` : ""} title="${esc(c[0])}">
    <span class="wear w-${c[8]}">${c[8]}</span><div class="pic">${picture(c)}</div>
    <div class="wp">${esc(c[7].split(" | ")[0])}</div><div class="nm">${esc(name)}</div><div class="pr">${fmt(c[1])}</div>${o.btn || ""}</div>`;
}
function emptyView(dir){                              // великі шеврони, як на еталоні
  const ch = [0, 1, 2].map(i => {
    const y = 12 + i * 14;
    const pts = dir === "up" ? `8,${y + 10} 30,${y} 52,${y + 10}` : `8,${y} 30,${y + 10} 52,${y}`;
    return `<polyline points="${pts}" fill="none" stroke="#c6ff5a" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" opacity="${i === 1 ? 1 : .35}"/>`;
  }).join("");
  return `<div class="empty-view"><svg class="ghost" viewBox="0 0 120 50"><g fill="#fff">${SHAPES.rifle}</g></svg>` +
         `<svg class="chev" viewBox="0 0 60 60">${ch}</svg></div>`;
}
function renderStats(){
  $("stats").innerHTML =
    `<span class="pill">${t("upgrades")}: <b>${S.upg}</b></span>` +
    `<span class="pill">${t("wins")}: <b>${S.wins}</b></span>` +
    `<span class="pill">${t("casesN")}: <b>${S.cases}</b></span>`;
}
function renderFeed(){
  $("feed").innerHTML = S.feed.length ? S.feed.map(e => {
    const time = new Date(e.ts).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
    let txt, cls;
    if(e.t === "case"){
      const cs = CASES.find(c => c.id === e.c);
      txt = f("f_case", {c:cs ? cs.name : e.c, i:nm(e.item)}); cls = "f-case";
    } else if(e.t === "up"){
      const st = e.stake.map(nm).concat(e.coins ? [`${fmt(e.coins)} ${t("coins")}`] : []).join(", ");
      txt = f(e.win ? "f_win" : "f_lose", {ch:e.chance, s:st, i:nm(e.item)});
      cls = e.win ? "f-win" : "f-lose";
    } else { txt = f("f_adv", {d:e.d, r:e.r.coins ? `+${e.r.coins} ${t("coins")}` : nm(e.r.skin)}); cls = "f-adv"; }
    return `<div class="${cls}"><small>${time}</small>${txt}</div>`;
  }).join("") : `<div class="empty">${t("feedEmpty")}</div>`;
}
function renderInv(){
  $("inv").innerHTML = S.inv.length ? S.inv.map(i => card(byName(i.n), {
    id:i.id, sel:selInv.has(i.id),
    btn:`<button class="act" data-sell="${i.id}">${t("sell")}</button>`
  })).join("") : `<div class="empty">${t("emptyInv")}</div>`;
}
let catList = [], catShown = 0;
const CHUNK = 90;                                     // скіни довантажуються порціями під час прокрутки
const catCard = c => card(c, {sel:c[0] === target, btn:`<button class="act" data-buy="${esc(c[0])}">${t("buy")} ${fmt(c[1])}</button>`});
function renderCat(reset){
  const q = $("q").value.trim().toLowerCase(), ty = $("typeSel").value;
  const [lo, hi] = RANGES[$("range").value], s = $("sort").value;
  catList = CATALOG
    .filter(c => (ty === "all" || c[3] === ty) && c[1] >= lo && c[1] < hi && (!q || c[0].toLowerCase().includes(q)))
    .sort((a, b) => s === "az" ? a[0].localeCompare(b[0]) : s === "desc" ? b[1] - a[1] : a[1] - b[1]);
  const g = $("cat"), keep = reset ? CHUNK : Math.max(CHUNK, catShown), top = reset ? 0 : g.scrollTop;
  g.innerHTML = catList.length ? catList.slice(0, keep).map(catCard).join("") : `<div class="empty">${t("nothing")}</div>`;
  catShown = Math.min(keep, catList.length); g.scrollTop = top;
}
$("cat").onscroll = () => {
  const g = $("cat");
  if(catShown < catList.length && g.scrollTop + g.clientHeight > g.scrollHeight - 300){
    const next = catList.slice(catShown, catShown + CHUNK);
    g.insertAdjacentHTML("beforeend", next.map(catCard).join("")); catShown += next.length;
  }
};
function markTarget(){
  document.querySelectorAll("#cat .skin").forEach(e => e.classList.toggle("sel", e.dataset.n === target));
}
function renderCases(){
  const q = $("cq").value.trim().toLowerCase(), s = $("csort").value;
  const list = CASES.filter(c => c.name.toLowerCase().includes(q))
    .sort((a, b) => s === "az" ? a.name.localeCompare(b.name) : s === "desc" ? b.price - a.price : a.price - b.price);
  $("cases").innerHTML = list.length ? list.map(c => `<div class="case" style="--cc:${c.color}">
    <div class="box">${crateSvg(c.color, c.emoji)}</div><div class="nm" title="${esc(c.name)}">${esc(c.name)}</div>
    <div class="rng">${fmt(c.lo)} – ${fmt(c.hi)}</div>
    <button class="btn small" data-case="${c.id}">${t("open")} · ${fmt(c.price)}</button></div>`).join("")
    : `<div class="empty">${t("nothing")}</div>`;
  $("ccount").textContent = CASES.length + " " + t("cCount");
}

// ===== Рендер: календар =====
const WD = {uk:["Пн","Вт","Ср","Чт","Пт","Сб","Нд"], en:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]};
function coinSvg(n){
  const k = n >= 60 ? 3 : n >= 20 ? 2 : 1;
  let g = "";
  for(let i = 0; i < k; i++)
    g += `<ellipse cx="20" cy="${31 - i * 7}" rx="13" ry="5.5" fill="#b87a14"/><ellipse cx="20" cy="${28 - i * 7}" rx="13" ry="5.5" fill="#ffd34a" stroke="#fff3b0" stroke-opacity=".7"/>`;
  return `<svg viewBox="0 0 40 40" aria-hidden="true">${g}</svg>`;
}
const chestSvg = () => `<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="5" y="17" width="30" height="17" rx="3" fill="#1f9d57"/><rect x="5" y="10" width="30" height="10" rx="4" fill="#3ddc84"/><rect x="5" y="19" width="30" height="2" fill="#0d3a21" opacity=".5"/><rect x="17" y="17" width="6" height="9" rx="1.5" fill="#c6ff5a"/></svg>`;
function untilMidnight(){
  const n = new Date(), m = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1);
  const s = Math.max(0, Math.floor((m - n) / 1000));
  return [s / 3600 | 0, (s % 3600) / 60 | 0, s % 60].map(x => String(x).padStart(2, "0")).join(":");
}
function streak(){
  const today = new Date().getDate();
  let d = S.adv.days.includes(today) ? today : today - 1, n = 0;
  while(d >= 1 && S.adv.days.includes(d)){ n++; d--; }
  return n;
}
function renderAdvent(){
  if(S.adv.m !== mon()) S.adv = {m:mon(), days:[]};
  const now = new Date(), today = now.getDate(), dim = daysInMonth();
  const off = (new Date(now.getFullYear(), now.getMonth(), 1).getDay() + 6) % 7;
  const got = S.adv.days.length, tr = adventReward(today, dim), todayDone = S.adv.days.includes(today);
  const label = r => r.coins ? `+${r.coins}` : esc(byName(r.skin)[7].split(" | ")[1] || r.skin);
  const icon = r => r.skin ? picture(byName(r.skin)) : r.kind === "chest" ? chestSvg() : coinSvg(r.coins);
  let month = now.toLocaleDateString(lang === "uk" ? "uk-UA" : "en-US", {month:"long", year:"numeric"});
  month = month.charAt(0).toUpperCase() + month.slice(1);
  $("advHero").innerHTML = `
    <div class="ah-top"><div class="ah-month">${esc(month)}</div><div class="ah-streak">🔥 ${t("streak")}: <b>${streak()}</b></div></div>
    <div class="ah-prog"><i><u style="width:${Math.round(got / dim * 100)}%"></u></i><span>${t("advGot")}: ${got}/${dim}</span></div>
    <div class="ah-today ${tr.skin ? byName(tr.skin)[2] : ""}">
      <div class="ah-ico">${icon(tr)}</div>
      <div class="ah-txt"><small>${t("advToday")}</small><b>${tr.coins ? "+" + tr.coins + " " + t("coins") : esc(tr.skin)}</b></div>
      ${todayDone ? `<div class="ah-next">${t("advNext")}<b id="advCd">${untilMidnight()}</b></div>`
                  : `<button class="btn primary" data-claim="1">${t("claim")}</button>`}
    </div>`;
  $("advWeek").innerHTML = WD[lang].map(w => `<span>${w}</span>`).join("");
  let h = "";
  for(let i = 0; i < off; i++) h += `<div class="door ghost"></div>`;
  for(let d = 1; d <= dim; d++){
    const r = adventReward(d, dim), done = S.adv.days.includes(d);
    const st = done ? "done" : d === today ? "today" : d < today ? "miss" : "lock";
    const mark = done ? '<i class="stamp">✓</i>' : st === "miss" ? '<i class="stamp">✕</i>' : st === "lock" ? '<i class="stamp">🔒</i>' : "";
    h += `<div class="door ${st} k-${r.kind}${r.skin ? " " + byName(r.skin)[2] : ""}${advPop === d ? " pop" : ""}"${st === "today" ? ' data-claim="1"' : ""}>
      <span class="dn">${d}</span><div class="di">${icon(r)}</div><div class="dl">${label(r)}</div>${mark}</div>`;
  }
  $("adv").innerHTML = h; advPop = 0;
}

// ===== Рендер: ваші скіни та ціль із цінами (видно і під час крутки) =====
function renderDuel(){
  const d = duelSnap || {items:S.inv.filter(i => selInv.has(i.id)).map(i => i.n), coins:balStake, target};
  if(!d.items.length && !(d.coins > 0) && !d.target){ $("duel").innerHTML = ""; return; }
  const mini = (n, cls) => {
    const c = byName(n);
    return `<div class="dc ${c[2]} ${cls || ""}" title="${esc(n)}"><div class="pic">${picture(c)}</div>
      <span class="dn2">${esc(c[7].split(" | ")[1] || c[7])}</span><b class="pr">${fmt(c[1])}</b></div>`;
  };
  const left = d.items.slice(0, 4).map(n => mini(n)).join("")
    + (d.items.length > 4 ? `<div class="dmore">+${d.items.length - 4}</div>` : "")
    + (d.coins > 0 ? `<div class="dc coins"><div class="pic">${coinSvg(d.coins)}</div><span class="dn2">${t("coins")}</span><b class="pr">${fmt(d.coins)}</b></div>` : "");
  const right = d.target ? mini(d.target, d.win === true ? "won" : d.win === false ? "lost" : "") : `<div class="dc ghost">?</div>`;
  $("duel").innerHTML = `<div class="dl">${left || '<div class="dc ghost">?</div>'}</div><div class="darrow">➜</div><div class="dr">${right}</div>`;
}

// ===== Рендер: колесо, панелі, слайдер =====
const CIRC = 2 * Math.PI * 86;
function arcD(ch){            // зона виграшу симетрична відносно низу, де стоїть стрілка
  if(ch <= 0) return "";
  const a1 = (90 - 1.8 * ch) * Math.PI / 180, a2 = (90 + 1.8 * ch) * Math.PI / 180, r = 86;
  const p = a => [100 + r * Math.cos(a), 100 + r * Math.sin(a)].map(v => v.toFixed(2)).join(" ");
  return `M${p(a1)} A${r} ${r} 0 ${ch > 50 ? 1 : 0} 1 ${p(a2)}`;
}
function renderPanels(){
  const sel = S.inv.filter(i => selInv.has(i.id));
  $("stakeTitle").textContent = sel.length ? `${t("sel")}: ${sel.length} · ${fmt(skinsValue())}` : t("pickStake");
  $("stakeSub").textContent = t("pickMany");
  $("stakeView").innerHTML = sel.length
    ? `<div class="thumbs">${sel.slice(0, 4).map(i => { const c = byName(i.n); return `<div class="th ${c[2]}">${picture(c)}</div>`; }).join("")}${sel.length > 4 ? `<div class="more">+${sel.length - 4}</div>` : ""}</div>`
    : emptyView("down");
  const c = target ? byName(target) : null;
  $("tgtTitle").textContent = c ? (c[9] ? "StatTrak™ " : "") + c[7] : t("pickTarget");
  $("tgtSub").textContent = c ? `${wearName(c[8])} · ${fmt(c[1])}` : t("pickSub");
  $("tgtView").innerHTML = c ? `<div class="tbig ${c[2]}">${picture(c)}</div>` : emptyView("up");
}
function renderStage(){
  const sp = spinCh !== null, ch = sp ? spinCh : chance(), sv = stakeValue(), tp = target ? byName(target) : null;
  const maxB = Math.floor(S.bal * 100) / 100;
  if(balStake > maxB) balStake = maxB;
  $("bal").textContent = fmt(S.bal);
  $("arc").setAttribute("d", arcD(ch));
  $("pct").textContent = ch.toFixed(2) + "%";
  $("chlab").textContent = t(ch < 25 ? "chLow" : ch < 55 ? "chMid" : "chHigh");
  $("inVal").textContent = fmt(sv);
  $("mult").textContent = tp && sv ? "x" + (tp[1] / sv).toFixed(2) : "x0";
  $("tgtPrice").textContent = tp ? fmt(tp[1]) : "—";
  $("balVal").textContent = fmt(balStake); $("balMax").textContent = fmt(maxB);
  $("balRange").max = maxB; $("balRange").value = balStake;
  $("mch").max = S.set.max; $("mch").disabled = busy; if(ch > 0) $("mch").value = ch;
  $("mchv").textContent = ch.toFixed(1) + "%";
  $("go").disabled = !busy && (ch < S.set.min || !tp || sv <= 0);
  $("go").textContent = busy ? "⏭ " + t("skip") : "⏫ " + t("upgrade");
  $("go").classList.toggle("skip", busy);
  renderPanels(); renderDuel(); renderToggles();
}
function renderAll(){ renderStats(); renderFeed(); renderInv(); renderCat(false); renderStage(); }
function renderEverything(){ renderAll(); renderCases(); renderAdvent(); }

// ===== Мова =====
function applyLang(){
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(e => e.textContent = t(e.dataset.i18n));
  document.querySelectorAll("[data-i18n-ph]").forEach(e => e.placeholder = t(e.dataset.i18nPh));
  document.querySelectorAll("[data-lang]").forEach(b => b.classList.toggle("on", b.dataset.lang === lang));
  try{ localStorage.setItem("upg_lang", lang); }catch(e){}
  showRes(); renderEverything();
}
document.querySelectorAll("[data-lang]").forEach(b => b.onclick = () => { lang = b.dataset.lang; applyLang(); });

// ===== Навігація між сторінками =====
document.querySelectorAll("[data-page]").forEach(b => b.onclick = () => {
  document.querySelectorAll("[data-page]").forEach(x => x.classList.toggle("on", x === b));
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("on", p.id === "page-" + b.dataset.page));
});

// ===== Апгрейд =====
$("go").onclick = async () => {
  if(busy){ skipNow = true; return; }                  // під час крутки кнопка працює як «Пропустити»
  if($("go").disabled) return;
  busy = true; SFX.click();
  const ch = chance(), ids = [...selInv], tg = target, coins = balStake;
  const names = S.inv.filter(i => ids.includes(i.id)).map(i => i.n);
  const delta = Math.random() * 360 - 180;             // де зупиниться стрілка відносно низу
  const win = Math.abs(delta) < ch * 1.8;              // зона виграшу: ±(шанс × 1.8°) навколо низу
  spinCh = ch; lastRes = null; showRes();
  duelSnap = {items:names, coins, target:tg};          // показуємо ставку й ціль з цінами
  S.inv = S.inv.filter(i => !ids.includes(i.id));      // ставка списується одразу
  addBal(-coins); selInv.clear(); balStake = 0; save(); renderInv(); renderStage();
  const a0 = curDeg, a1 = a0 + 360 * (S.set.fast ? 2 : 6) + (delta - lastDelta);
  let last = Math.floor(a0 / 6), lastT = 0;
  await animate(S.set.fast ? 1100 : 5200, (e, x) => {
    const a = a0 + (a1 - a0) * e, idx = Math.floor(a / 6), now = performance.now();
    $("ptr").setAttribute("transform", `rotate(${a} 100 100)`);
    if(idx !== last){ if(now - lastT > 28){ SFX.tick(1 - x); lastT = now; } last = idx; }
  });
  curDeg = a1; lastDelta = delta;
  if(duelSnap) duelSnap.win = win;
  S.upg++;
  if(win){ S.inv.push({id:++S.uid, n:tg}); S.wins++; }
  addFeed({t:"up", win, chance:ch, stake:names, coins, item:tg});
  setRes(win ? "win" : "lose", win ? "win" : "lose", win ? tg : "");
  busy = false; spinCh = null; save(); renderAll();
  win ? SFX.win() : SFX.lose(); flash(win ? "win" : "lose");
};

// швидкий вибір цілі: x2, x4… (за множником) та 35%, 55%… (за шансом)
$("quick").onclick = e => {
  const b = e.target.closest(".q");
  if(!b || busy || b.id === "gearBtn") return;
  const sv = stakeValue();
  if(sv <= 0) return setRes("e_pick", "lose");
  SFX.click(); clearDuel();
  pickNearest(b.dataset.x ? sv * +b.dataset.x : sv * S.set.edge / +b.dataset.c);
  renderStage(); markTarget();
};
$("mch").oninput = e => {                              // перетягуйте слайдер: ціль підбирається під потрібний шанс
  if(busy) return;
  const sv = stakeValue();
  if(sv <= 0){ renderStage(); return setRes("e_pick", "lose"); }
  clearDuel();
  pickNearest(sv * S.set.edge / +e.target.value);
  renderStage(); markTarget();
};
$("balRange").oninput = e => {
  if(busy) return;
  clearDuel();
  balStake = Math.min(+e.target.value, Math.floor(S.bal * 100) / 100);
  renderStage();
};

// ===== Інвентар і цілі =====
$("inv").onclick = e => {
  if(busy) return;
  const sell = e.target.closest("[data-sell]");
  if(sell){
    const id = +sell.dataset.sell, it = S.inv.find(i => i.id === id);
    addBal(byName(it.n)[1]); S.inv = S.inv.filter(i => i.id !== id); selInv.delete(id); SFX.coin();
    save(); renderAll(); return;
  }
  const c = e.target.closest("[data-id]");
  if(c){ const id = +c.dataset.id; selInv.has(id) ? selInv.delete(id) : selInv.add(id); SFX.click(); clearDuel(); renderInv(); renderStage(); }
};
$("sellSel").onclick = () => {
  if(busy) return;
  if(selInv.size) SFX.coin();
  S.inv.filter(i => selInv.has(i.id)).forEach(i => addBal(byName(i.n)[1]));
  S.inv = S.inv.filter(i => !selInv.has(i.id)); selInv.clear(); clearDuel(); save(); renderAll();
};
$("cat").onclick = e => {
  if(busy) return;
  const buy = e.target.closest("[data-buy]");
  if(buy){
    const c = byName(buy.dataset.buy);
    if(S.bal < c[1]) return setRes("e_money", "lose");
    addBal(-c[1]); S.inv.push({id:++S.uid, n:c[0]}); SFX.coin(); save(); renderAll(); return;
  }
  const c = e.target.closest(".skin");
  if(c){ target = c.dataset.n; SFX.click(); clearDuel(); renderStage(); markTarget(); }
};
$("q").oninput = () => renderCat(true); $("typeSel").onchange = () => renderCat(true);
$("range").onchange = () => renderCat(true); $("sort").onchange = () => renderCat(true);

// ===== Кейси =====
function draw(cs){
  let r = Math.random(), i = 0;
  for(; i < cs.ws.length - 1; i++){ r -= cs.ws[i]; if(r <= 0) break; }
  return cs.items[i];
}
$("cases").onclick = async e => {
  const b = e.target.closest("[data-case]");
  if(!b || busy) return;
  const cs = CASES.find(c => c.id === b.dataset.case);
  if(S.bal < cs.price) return setRes("e_money", "lose");
  busy = true; addBal(-cs.price); save(); renderStage(); SFX.click();
  const win = draw(cs), WIN_AT = 30, reel = $("reel"), strip = $("strip");
  const seq = Array.from({length:40}, (_, i) => i === WIN_AT ? win : draw(cs));
  reel.innerHTML = seq.map(n => card(byName(n))).join("");
  strip.classList.add("on");
  reel.style.transform = "translateX(0)";
  const x1 = 6 + WIN_AT * 104 + 50 - strip.clientWidth / 2 + (Math.random() * 40 - 20);
  let last = -1, lastT = 0;
  await animate(S.set.fast ? 900 : 3600, (e2, x) => {
    const px = x1 * e2, now = performance.now();
    reel.style.transform = `translateX(${-px}px)`;
    const idx = Math.floor((px + strip.clientWidth / 2 - 6) / 104);
    if(idx !== last){ if(last >= 0 && now - lastT > 28){ SFX.tick(1 - x); lastT = now; } last = idx; }
  });
  if(reel.children[WIN_AT]) reel.children[WIN_AT].classList.add("hit");
  S.inv.push({id:++S.uid, n:win}); S.cases++;
  addFeed({t:"case", c:cs.id, item:win});
  busy = false; save(); renderAll(); setRes("dropped", "win", " " + win);
  SFX.drop(byName(win)[2]);
};
$("cq").oninput = renderCases; $("csort").onchange = renderCases;

// ===== Календар =====
$("page-advent").onclick = e => {
  if(!e.target.closest("[data-claim]")) return;
  if(S.adv.m !== mon()) S.adv = {m:mon(), days:[]};
  const d = new Date().getDate();
  if(S.adv.days.includes(d)) return;
  const r = adventReward(d, daysInMonth());
  if(r.coins) addBal(r.coins); else S.inv.push({id:++S.uid, n:r.skin});
  S.adv.days.push(d); addFeed({t:"adv", d, r}); save();
  r.skin ? SFX.drop(byName(r.skin)[2]) : SFX.coin();
  advPop = d; renderAll(); renderAdvent();
};

// ===== Вікна: налаштування та інформація =====
const LIM = {edge:[1,300], max:[1,99], min:[0.01,50], bonus:[0,100000], secs:[1,86400]};
Object.keys(LIM).forEach(k => $("s_" + k).oninput = e => {
  const v = parseFloat(e.target.value);
  if(isNaN(v)) return;
  S.set[k] = Math.max(LIM[k][0], Math.min(LIM[k][1], v));
  if(k === "secs") nextBonus = Date.now() + S.set.secs * 1000;
  save(); renderStage();
});
function openSettings(){
  Object.keys(LIM).forEach(k => $("s_" + k).value = S.set[k]);
  $("settings").classList.remove("hide");
}
$("setBtn").onclick = openSettings; $("gearBtn").onclick = openSettings;
$("setClose").onclick = () => $("settings").classList.add("hide");
$("infoBtn").onclick = () => $("info").classList.remove("hide");
$("infoClose").onclick = () => $("info").classList.add("hide");

// ===== Бонус кожні N секунд, таймер календаря =====
setInterval(() => {
  if(Date.now() >= nextBonus){
    addBal(S.set.bonus); nextBonus = Date.now() + S.set.secs * 1000; save(); renderStage();
  }
  const s = Math.max(0, Math.ceil((nextBonus - Date.now()) / 1000));
  $("timerTxt").textContent = t("timer").replace("{n}", S.set.bonus).replace("{s}", s);
  $("bar").style.width = (100 - 100 * s / S.set.secs) + "%";
  const cd = $("advCd"); if(cd) cd.textContent = untilMidnight();
  if(new Date().getDate() !== advDay){ advDay = new Date().getDate(); renderAdvent(); }
}, 500);

// ===== Старт =====
for(let i = 0; i < 60; i++){            // риски на кільці колеса
  const a = i * 6 * Math.PI / 180, r1 = 92, r2 = i % 5 ? 94.5 : 97;
  $("ticks").insertAdjacentHTML("beforeend",
    `<line x1="${100 + r1 * Math.sin(a)}" y1="${100 - r1 * Math.cos(a)}" x2="${100 + r2 * Math.sin(a)}" y2="${100 - r2 * Math.cos(a)}"/>`);
}
applyLang();
loadImages();
